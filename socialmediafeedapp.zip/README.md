# Social Media Feed Application

A production-quality, frontend-only social media feed application built with React, Vite, TypeScript, Redux Toolkit, and Tailwind CSS.

## Features

- **Authentication**: Registration, login, logout with session persistence via cookies
- **Auth Pages**: 50/50 split layout—left: carousel slides; right: center-aligned form
- **Dashboard Layout**: After login—sticky sidebar, breadcrumbs in header, hamburger menu
- **Feed**: Create posts with rich text, images, videos; comment, like, share with owner-only edit/delete
- **Media**: Images and videos in posts; collage maker for multiple images
- **Hashtags, Mentions, Locations**: Use #hashtag, @mention, and add location to posts
- **Search & Filter**: Search by keyword, username; sort by newest, oldest, most liked, most commented, most shared
- **Toast Notifications**: Error toasts (user must close), success toasts (auto-close)
- **Admin Dashboard**: Admin account can view all users, post stats, and download Excel reports
- **Theme**: Dark and light mode with persistence
- **Security**: Input sanitization, protected routes, safe cookie/localStorage usage
- **Testing**: Unit and component tests with Vitest and React Testing Library

## Tech Stack

- React 19, Vite 8, TypeScript
- Redux Toolkit, React Router 7
- Tailwind CSS 4, Tiptap (rich text), DOMPurify, xlsx

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Default Credentials

| Account | Username | Password |
|---------|----------|----------|
| **Admin** | admin | admin@123 |
| Alice | alice | password123 |
| Bob | bob | password123 |

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run test` | Run tests |
| `npm run preview` | Preview production build |

## Documentation

- [FEATURESLIST.md](FEATURESLIST.md) – Full feature list
- [HOWTOUSE.md](HOWTOUSE.md) – User guide
- [PROJECTSETUP.md](PROJECTSETUP.md) – Setup instructions
- [PROJECTEXECUTION.md](PROJECTEXECUTION.md) – Run, test, deploy
- [BRD.md](BRD.md) – Business Requirements Document

## License

MIT
